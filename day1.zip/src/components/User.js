import React, { Component } from "react";

export default class User extends Component {
  render() {
    return (
      <div>
       {this.props.ud}
       <button onClick={(e)=>{this.props.deleteUser(this.props.ud)}}>Delete</button>
      </div>
    );
  }
}
