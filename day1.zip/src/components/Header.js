import React, { Component } from "react";

export default class Header extends Component {
  render() {
    return (
      <div>
        <p> {this.props.hdata}</p>

        <hr/>
        <button onClick={this.props.da} disabled={!this.props.hasData}>Delete All</button>
      </div>
    );
  }
}
