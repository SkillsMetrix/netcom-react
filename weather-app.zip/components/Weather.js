import {
  StyleSheet,
  Text,
  View,
  ImageBackground,
  Dimensions,
} from "react-native";
import { haze, rainy, snow, sunny } from "../assets/background/index";
import React, { useEffect, useState } from "react";
import SearchBar from "./SearchBar";
import { Colors } from "react-native/Libraries/NewAppScreen";

export default function Weather({ weatherData }) {
  const {
    weather,
    name,
    main: { temp, humidity },
    wind:{speed}
  } = weatherData;
  const [backgroundImage, setBackgroundImage] = useState(null);
  const [{ main }] = weather;
  useEffect(() => {
    console.log(main);
    setBackgroundImage(getImage(main));
  }, [weatherData]);
  function getImage(weather) {
    if (weather === "Snow") return snow;
    if (weather === "Clear") return sunny;
    if (weather === "Rain") return rainy;
    if (weather === "Haze") return haze;

    return sunny;
  }
  return (
    <View style={styles.container}>
      <ImageBackground
        source={backgroundImage}
        style={styles.bgi}
        resizeMode="cover"
      >
        <SearchBar/>
        <View style={{ alignItems: "center" }}>
          <Text style={{ ...styles.headerText,fontWeight:'bold' }}>{name}</Text>
          <Text style={{ ...styles.headerText,fontWeight:'bold' }}>{main}</Text>
          <Text style={{ ...styles.headerText }}>{temp}</Text>
        </View>
        <View style={styles.info}>
        <Text style={{ fontSize:22 }}>Humidity</Text>
        <Text style={{ fontSize:22 }}>{humidity}%</Text>

        </View>

        <View style={styles.info}>
        <Text style={{ fontSize:22 }}>Wind Speed</Text>
        <Text style={{ fontSize:22 }}>{speed}m/s</Text>

        </View>
      </ImageBackground>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
  },
  bgi: {
    flex: 1,
    width: Dimensions.get("screen").width,
  },
  headerText: {
    fontSize: 36,
    marginTop: 10,
    
  },
});
