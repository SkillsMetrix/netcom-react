import { StatusBar } from 'expo-status-bar';
import { Button, StyleSheet, Text, View } from 'react-native';
import RestApp from './RestApp';

export default function MainApp() {

  addUser=()=>{
    alert('user added')
  }

  return (
    <View>
       <RestApp/>
      
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
