import { Button, StyleSheet, Text, View } from "react-native";
import React, { useEffect, useState } from "react";
// functional component can also have 'state' and 'lifecycle' with using HOOKS
export default function UsersApp() {
  const [counter, setCounter] = useState(10);
  // this will behave like componentDidMount
  useEffect(() => {
    console.log("call only on load");
  }, []);
  // this will behave like componentDidupdate
  useEffect(() => {
    console.log("call only on state change");
  }, [counter]);
  // initialize the state

  // updating the state
  const increment = () => {
    setCounter(counter + 1);
  };
  const decrement = () => {
    setCounter(counter - 1);
  };

  return (
    <View>
      <Text>UsersApp Count Value: {counter}</Text>
      <Button title="INC" onPress={() => setCounter(counter + 1)}></Button>
      <Button title="DEC" onPress={decrement}></Button>
    </View>
  );
}

const styles = StyleSheet.create({});
