import { StatusBar } from "expo-status-bar";
import { Button, StyleSheet, Text, View } from "react-native";
import React, { useState, useEffect } from "react";
import axios from "axios";
import RestAppData from "./RestAppData";
const URL = "https://jsonplaceholder.typicode.com/users";
function RestApp(props) {
  state = {
    users: [],
  };
  //initialize the state with empty array of users
  const [users, setUsers] = useState([]);
  useEffect(() => {
    axios
      .get(URL)
      .then((response) => response.data)
      .then((data) => {
        setUsers(data);
      });
  }, []);
  return (
    <View>
      <RestAppData data={users} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
});

export default RestApp;
