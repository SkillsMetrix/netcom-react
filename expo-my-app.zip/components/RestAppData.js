import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

export default function RestAppData(props) {
  return (
    <View>
      <Text>User Details</Text>
        {props.data.map((user) => (
          <Text key={user.id}>{user.name}</Text>
        ))}
    </View>
  )
}

const styles = StyleSheet.create({})