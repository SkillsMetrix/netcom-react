import { StatusBar } from 'expo-status-bar';
import { Button, StyleSheet, Text, View } from 'react-native';
import MainApp from './components/MainApp';
import UsersApp from './components/UsersApp';
import RestApp from './components/RestApp';
import {useState} from 'react'
import { MyContext } from './contextapp/MyContext';
import MainComp from './contextapp/MainComp';

export default function App() {

   const userData=[{name:'admin',email:'admin@mail.com'}]

    const [user,setUser]=useState(userData)

  return (
    <View style={styles.container}>
     
     <MyContext.Provider value={user}>
      <MainComp/>
     </MyContext.Provider>
     
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
