import { StyleSheet, Text, View } from 'react-native'
import React,{useContext} from 'react'
import {MyContext} from './MyContext'
 

export default function Welcome() {
  const myContext= useContext(MyContext)
  return (
    <View>
      <Text>Welcome Data</Text>
      {myContext.map((data)=> (
        <Text>{data.name}--- {data.email}</Text>
      ))}
    </View>
  )
}

const styles = StyleSheet.create({})