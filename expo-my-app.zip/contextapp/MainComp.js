import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import MyComponent from './MyComponent'

export default function MainComp() {
  return (
    <View>
      <MyComponent/>
    </View>
  )
}

const styles = StyleSheet.create({})