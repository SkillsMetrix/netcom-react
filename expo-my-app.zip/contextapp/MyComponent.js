import { StyleSheet, Text, View } from 'react-native'
import React,{useContext} from 'react'
import {MyContext} from './MyContext'
import Welcome from './Welcome'
 

export default function MyComponent() {
   return (
    <View>
     

      <Welcome/>
    </View>
  )
}

const styles = StyleSheet.create({})