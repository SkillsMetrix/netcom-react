 import User from "./User";

function Users(props) {
  
    return (
      <div>
       {props.udata.map((data)=>  <User ud={data} deleteUser={props.da}/>)}
       
      </div>
    );
  }

export default Users