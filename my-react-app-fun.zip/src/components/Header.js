function Header(props) {
  return (
    <div>
      <p> {props.hdata}</p>

      <hr />
      <button onClick={props.da} disabled={!props.hasData}>
        Delete All
      </button>
    </div>
  );
}
export default Header;
