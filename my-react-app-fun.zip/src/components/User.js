 
function User(props) {
   
    return (
      <div>
       {props.ud}
       <button onClick={(e)=>{props.deleteUser(props.ud)}}>Delete</button>
      </div>
    );
  }
export default User
