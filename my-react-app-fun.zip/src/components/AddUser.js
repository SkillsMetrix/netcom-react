 
function AddUser (props) {
 const addUser=(e)=>{
    e.preventDefault();
    const udata=e.target.elements.uname.value
    
      props.au(udata)
  }
   
    return (
      <div>
       <form onSubmit={addUser}>
        UserName:<input type="text" name='uname'/>
       <button >Add User</button>
       </form>
      </div>
    );
  }

export default AddUser