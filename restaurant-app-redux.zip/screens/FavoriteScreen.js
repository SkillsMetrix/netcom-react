import { Text, StyleSheet, View } from 'react-native'
import React, { Component, useContext } from 'react'
import { FavContext } from '../store/context/fav-context'
import { MEALS } from '../data/dummy-data'
import MealsLIst from '../components/MealsList/MealsLIst'

export default function FavoriteScreen () {
  const favMealCtx= useContext(FavContext)
   
  const favMeals= MEALS.filter((meal)=> favMealCtx.ids.includes(meal.id))
    return (
     <MealsLIst items={favMeals}/>
    )
  
}

const styles = StyleSheet.create({})