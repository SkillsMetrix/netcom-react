import { createContext, useState } from "react";

export const FavContext = createContext({
  ids: [],
  addFavorite: (id) => {},
  removeFavorite: (id) => {},
});

function FavContextProvider({ children }) {
  const [favMealId, setFavMealId] = useState([]);
  function addFav(id) {
    console.log("fav is added");
    setFavMealId((currentFavIds) => [...currentFavIds, id]);
  }
  function removeFav(id) {
    console.log("fav is removed");
    setFavMealId((currentFavIds) =>
      currentFavIds.filter((mealId) => mealId !== id)
    );
  }

  const value = {
    ids: favMealId,
    addFav: addFav,
    removeFav: removeFav,
  };
  return <FavContext.Provider value={value}>{children}</FavContext.Provider>;
}
export default FavContextProvider;
